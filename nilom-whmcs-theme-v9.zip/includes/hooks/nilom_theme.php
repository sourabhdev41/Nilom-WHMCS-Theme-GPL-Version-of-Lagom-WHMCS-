<?php
/**
 * =========================================================================
 *  Hook Name: Nilom Standalone Theme Engine
 *  Author: NRWThemes (https://nrwone.in)
 *  Theme: Nilom Client & Orderform Theme
 *  Target Versions: WHMCS 9.0.6, 9.0.6-release.1, 9.0.9+
 *  PHP Version: PHP 8.1, PHP 8.2, PHP 8.3, PHP 8.4+
 *  License: Open Source / Standalone - Zero License System & Zero ionCube
 * =========================================================================
 */

defined('WHMCS') or die('Restricted access');

use WHMCS\Database\Capsule;
use WHMCS\View\Menu\Item as MenuItem;

/*
 * -------------------------------------------------------------------------
 *  1. Nilom Language Translation Helper ($rslang / $nilomlang)
 * -------------------------------------------------------------------------
 */
if (!class_exists('NilomLang', false)) {
    class NilomLang {
        private $translations = [];

        public function __construct($lang = 'english', $templateDir = '') {
            $lang = strtolower(trim($lang ?: 'english'));
            if (empty($templateDir)) {
                $templateDir = ROOTDIR . '/templates/nilom';
            }
            $file = $templateDir . '/core/lang/' . $lang . '.php';
            $fallback = $templateDir . '/core/lang/english.php';

            if (file_exists($file)) {
                $loaded = include $file;
                if (is_array($loaded)) {
                    $this->translations = $loaded;
                }
            } elseif (file_exists($fallback)) {
                $loaded = include $fallback;
                if (is_array($loaded)) {
                    $this->translations = $loaded;
                }
            }
        }

        public function trans($key, $params = []) {
            if (!is_string($key) || empty($key)) {
                return '';
            }
            $parts = explode('.', $key);
            $curr = $this->translations;
            foreach ($parts as $p) {
                if (is_array($curr) && isset($curr[$p])) {
                    $curr = $curr[$p];
                } else {
                    $last = end($parts);
                    return ucwords(str_replace('_', ' ', $last));
                }
            }
            return is_string($curr) ? $curr : $key;
        }

        public function __call($name, $arguments) {
            return '';
        }
    }
}

/*
 * -------------------------------------------------------------------------
 *  2. Compatibility Shims (Prevents conflicts & undefined method errors)
 * -------------------------------------------------------------------------
 */
if (!class_exists('\RSThemes\Models\Settings', false)) {
    eval('
    namespace RSThemes\Models {
        class Settings {
            public static function where($col, $val) {
                return new class($val) {
                    private $setting;
                    public function __construct($s) { $this->setting = $s; }
                    public function first() {
                        $defaults = [
                            "display_mode_switcher" => (object)["value" => "1"],
                            "display_mode_type" => (object)["value" => "switcher"],
                            "tld_cycle_switcher" => (object)["value" => "1"],
                            "product_description_style" => (object)["value" => "default"],
                            "product_domain_free_price" => (object)["value" => "0"],
                            "custom_language_list" => (object)["value" => "0"],
                            "custom_available_languages" => (object)["value" => ""],
                            "show_client_id" => (object)["value" => "0"],
                            "menu_cache_disabled" => (object)["value" => "1"],
                            "menu_cache_disabled_menu" => (object)["value" => "all"],
                        ];
                        return $defaults[$this->setting] ?? (object)["value" => "0"];
                    }
                };
            }
        }
        class Configuration {
            public function getConfig($key) {
                return $GLOBALS["CONFIG"][$key] ?? "english";
            }
        }
        class Display {
            public static function where($col, $val) {
                return new class {
                    public function first() { return (object)["id" => 1, "name" => "Default"]; }
                    public function value($col) { return "Default"; }
                };
            }
        }
        class Page {
            public static function all() { return []; }
            public static function where($col, $val) {
                return new class {
                    public function first() { return null; }
                };
            }
        }
        class DisplayRule {
            public static function where($col, $val) {
                return new class {
                    public function first() { return null; }
                    public function where($col, $val) { return $this; }
                };
            }
        }
        class HtmlCache {
            public static function where($col, $val) {
                return new class {
                    public function first() { return null; }
                };
            }
        }
    }
    namespace RSThemes\Helpers {
        class AddonHelper {
            public static function getCurrentTemplate() { return "nilom"; }
            public static function getCurrentTemplateObject() { return null; }
            public static function getTemplate() { return "nilom"; }
            public static function getNotActiveTemplates() { return []; }
            public static function getActiveTemplates() { return ["nilom"]; }
            public static function __callStatic($name, $arguments) { return null; }
        }
        class Lang extends \NilomLang {}
        class RSLang extends \NilomLang {}
    }
    ');
}

/*
 * -------------------------------------------------------------------------
 *  3. Central Theme Configuration Loader Helper
 *     Reads from Addon Module settings in DB, with fallback to theme-config.php
 * -------------------------------------------------------------------------
 */
function nilom_get_theme_config($templateName = 'nilom') {
    static $cachedConfig = null;
    if ($cachedConfig !== null) {
        return $cachedConfig;
    }

    $defaultConfig = [
        'theme_name'             => 'Nilom',
        'theme_version'          => '2.3.2',
        'author'                 => 'NRWThemes',
        'author_url'             => 'https://nrwone.in',
        'style'                  => 'default',
        'color'                  => 'default',
        'custom_hex_color'       => '',
        'layout'                 => 'default',
        'footer_layout'          => 'default',
        'display_mode'           => 'switcher',
        'sticky_nav'             => true,
        'mobile_menu'            => 'dropdown',
        'hide_inactive_services' => false,
        'tld_cycle_switcher'     => true,
        'custom_logo_url'        => '',
        'custom_css'             => '',
    ];

    // 1. Read file configuration
    $configPath = ROOTDIR . '/templates/' . $templateName . '/theme-config.php';
    if (file_exists($configPath)) {
        $loaded = include $configPath;
        if (is_array($loaded)) {
            $defaultConfig = array_merge($defaultConfig, $loaded);
        }
    }

    // 2. Read Addon Module settings from database (if configured)
    try {
        if (class_exists('\WHMCS\Database\Capsule', false)) {
            $addonSettings = Capsule::table('tbladdonmodules')
                ->where('module', 'nilom_theme')
                ->pluck('value', 'setting')
                ->all();

            if (!empty($addonSettings)) {
                if (!empty($addonSettings['theme_style'])) {
                    $defaultConfig['style'] = $addonSettings['theme_style'];
                }
                if (!empty($addonSettings['theme_color'])) {
                    $defaultConfig['color'] = $addonSettings['theme_color'];
                }
                if (!empty($addonSettings['custom_hex_color'])) {
                    $defaultConfig['custom_hex_color'] = $addonSettings['custom_hex_color'];
                }
                if (!empty($addonSettings['theme_layout'])) {
                    $defaultConfig['layout'] = $addonSettings['theme_layout'];
                }
                if (!empty($addonSettings['footer_layout'])) {
                    $defaultConfig['footer_layout'] = $addonSettings['footer_layout'];
                }
                if (!empty($addonSettings['display_mode'])) {
                    $defaultConfig['display_mode'] = $addonSettings['display_mode'];
                }
                if (isset($addonSettings['sticky_nav'])) {
                    $defaultConfig['sticky_nav'] = ($addonSettings['sticky_nav'] === 'on');
                }
                if (!empty($addonSettings['custom_css'])) {
                    $defaultConfig['custom_css'] = $addonSettings['custom_css'];
                }
            }
        }
    } catch (\Throwable $e) {
        // Fallback gracefully
    }

    $cachedConfig = $defaultConfig;
    return $cachedConfig;
}

/*
 * -------------------------------------------------------------------------
 *  4. Main Client Area Page Hook
 *     Injects $RSThemes, $NRWThemes, $rslang, and layout variables
 * -------------------------------------------------------------------------
 */
add_hook('ClientAreaPage', 1, function($vars) {
    $activeTemplate = $vars['template'] ?? '';
    
    // Only execute if active template is nilom (or lagom2)
    if ($activeTemplate !== 'nilom' && $activeTemplate !== 'lagom2' && strpos($activeTemplate, 'nilom') === false) {
        return [];
    }

    $templateDir = ROOTDIR . '/templates/' . $activeTemplate;
    $config = nilom_get_theme_config($activeTemplate);

    // Active Language
    $activeLang = $vars['language'] ?? $_SESSION['Language'] ?? ($GLOBALS['CONFIG']['Language'] ?? 'english');
    $langHelper = new NilomLang($activeLang, $templateDir);

    // Live session/query overrides
    $activeStyle = $_GET['rsstyle'] ?? $_SESSION['rsstyle'] ?? $config['style'];
    $activeColor = $_GET['rscolor'] ?? $_SESSION['rscolor'] ?? $config['color'];
    $activeLayout = $_GET['rslayout'] ?? $_SESSION['rslayout'] ?? $config['layout'];
    $footerLayout = $config['footer_layout'] ?? 'default';

    // Validate style
    $validStyles = ['default', 'modern', 'depth', 'futuristic'];
    if (!in_array($activeStyle, $validStyles, true)) {
        $activeStyle = 'default';
    }

    // Validate layout
    $validLayouts = ['default', 'condensed', 'left-nav', 'left-nav-wide'];
    if (!in_array($activeLayout, $validLayouts, true)) {
        $activeLayout = 'default';
    }

    // Body classes per style
    $styleClasses = [
        'default'    => 'lagom-default',
        'modern'     => 'lagom-modern',
        'depth'      => 'lagom-depth',
        'futuristic' => 'lagom-futuristic',
    ];
    $currentStyleClass = $styleClasses[$activeStyle] ?? 'lagom-default';

    // Body classes per layout
    $layoutClasses = [
        'default'       => 'lagom-layout-top',
        'condensed'     => 'lagom-layout-condensed',
        'left-nav'      => 'lagom-layout-left',
        'left-nav-wide' => 'lagom-layout-left-wide',
    ];
    $currentLayoutClass = $layoutClasses[$activeLayout] ?? 'lagom-layout-top';

    // Layout paths
    $layoutRelPath = "templates/{$activeTemplate}/core/layouts/main-menu/{$activeLayout}/{$activeLayout}.tpl";
    if (!file_exists(ROOTDIR . '/' . $layoutRelPath)) {
        $layoutRelPath = "templates/{$activeTemplate}/core/layouts/main-menu/default/default.tpl";
        $activeLayout = 'default';
    }

    $footerRelPath = "templates/{$activeTemplate}/core/layouts/footer/{$footerLayout}/{$footerLayout}.tpl";
    if (!file_exists(ROOTDIR . '/' . $footerRelPath)) {
        $footerRelPath = "templates/{$activeTemplate}/core/layouts/footer/default/default.tpl";
    }

    // Dark Mode Detection
    $isDarkMode = false;
    if (isset($_GET['dark_mode'])) {
        $isDarkMode = ($_GET['dark_mode'] === '1' || $_GET['dark_mode'] === 'true');
        setcookie('lagom_client_theme_dark_mode', $isDarkMode ? 'true' : 'false', time() + 31536000, '/');
    } elseif ($config['display_mode'] === 'force_dark') {
        $isDarkMode = true;
    } elseif ($config['display_mode'] === 'force_light') {
        $isDarkMode = false;
    } elseif (isset($_COOKIE['lagom_client_theme_dark_mode']) && $_COOKIE['lagom_client_theme_dark_mode'] === 'true') {
        $isDarkMode = true;
    }

    // Build the $RSThemes structure expected by the templates
    $RSThemes = [
        'template'        => $activeTemplate,
        'templateVersion' => $config['theme_version'],
        'layouts'         => [
            'name'           => $activeLayout,
            'templateLayout' => $activeLayout,
            'mediumPath'     => $layoutRelPath,
            'vars'           => [
                'bodyClass' => $currentLayoutClass,
                'type'      => ($activeLayout === 'condensed' ? 'condensed' : 'default'),
            ],
        ],
        'footer-layouts'  => [
            'name'       => $footerLayout,
            'mediumPath' => $footerRelPath,
            'vars'       => [],
        ],
        'styles'          => [
            'name'   => $activeStyle,
            'vars'   => [
                'bodyClass'  => $currentStyleClass,
                'futuristic' => ($activeStyle === 'futuristic'),
            ],
            'colors' => null,
        ],
        'addonSettings'   => [
            'show_affixed_navigation' => (!empty($config['sticky_nav'])) ? 'enabled' : 'disabled',
            'display_mode_switcher'   => ($config['display_mode'] === 'switcher') ? '1' : '0',
            'display_mode_type'       => ($config['display_mode'] === 'force_dark' ? 'force' : 'switcher'),
            'mobile_menu_style'       => $config['mobile_menu'] ?? 'dropdown',
            'hide_discounts'          => 'false',
        ],
        'pages'           => [],
        'pageSettings'    => [],
    ];

    // Load layouthelpers.php
    $layoutHelpersFile = $templateDir . '/core/config/layouthelpers.php';
    $ignoreSidebars = false;
    $ignoreHeader = false;
    $forceSidebar = false;
    $ignoreMainBody = false;
    $sidebarOnRight = false;

    if (file_exists($layoutHelpersFile)) {
        $layoutConfig = include $layoutHelpersFile;
        $currentFile = $vars['templatefile'] ?? '';
        if (is_array($layoutConfig) && isset($layoutConfig[$currentFile])) {
            $rule = $layoutConfig[$currentFile];
            $ignoreSidebars = (bool)($rule[0] ?? false);
            $ignoreHeader   = (bool)($rule[1] ?? false);
            $forceSidebar   = (bool)($rule[2] ?? false);
            $ignoreMainBody = (bool)($rule[3] ?? false);
            $sidebarOnRight = (bool)($rule[4] ?? false);
        }
    }

    // Load templateclasses.php
    $appMainBodyClasses = '';
    $bodyClasses = '';
    $mainContentClasses = '';
    $templateClassesFile = $templateDir . '/core/config/templateclasses.php';
    if (file_exists($templateClassesFile)) {
        $classesConfig = include $templateClassesFile;
        $currentFile = $vars['templatefile'] ?? '';
        if (is_array($classesConfig) && isset($classesConfig[$currentFile])) {
            $cRule = $classesConfig[$currentFile];
            $appMainBodyClasses = $cRule[0] ?? '';
            $bodyClasses        = $cRule[1] ?? '';
            $mainContentClasses = $cRule[2] ?? '';
        }
    }

    // Cache key for assets
    $cacheKey = substr(md5($config['theme_version'] . $activeStyle . $activeColor), 0, 8);

    return [
        'rslang'                 => $langHelper,
        'nilomlang'              => $langHelper,
        'RSThemes'               => $RSThemes,
        'NRWThemes'              => $config,
        'theme_version'          => $config['theme_version'],
        'assetsCacheKey'         => $cacheKey,
        'display_mode_switcher'  => [
            'dark'    => $isDarkMode ? 'true' : 'false',
            'enabled' => ($config['display_mode'] === 'switcher'),
        ],
        'lagom_logo_url'         => $config['custom_logo_url'] ?? '',
        'ignoreSidebars'         => $ignoreSidebars,
        'ignoreHeader'           => $ignoreHeader,
        'forceSidebar'           => $forceSidebar,
        'ignoreMainBody'         => $ignoreMainBody,
        'sidebarOnRight'         => $sidebarOnRight,
        'appMainBodyClasses'     => $appMainBodyClasses,
        'bodyClasses'            => $bodyClasses,
        'mainContentClasses'     => $mainContentClasses,
    ];
});

/*
 * -------------------------------------------------------------------------
 *  5. Head Output Hook: Inject Color Scheme CSS & Custom Styles
 * -------------------------------------------------------------------------
 */
add_hook('ClientAreaHeadOutput', 1, function($vars) {
    $activeTemplate = $vars['template'] ?? '';
    if ($activeTemplate !== 'nilom' && $activeTemplate !== 'lagom2' && strpos($activeTemplate, 'nilom') === false) {
        return '';
    }

    $config = nilom_get_theme_config($activeTemplate);
    $activeStyle = $_GET['rsstyle'] ?? $_SESSION['rsstyle'] ?? $config['style'];
    $activeColor = $_GET['rscolor'] ?? $_SESSION['rscolor'] ?? $config['color'];

    $output = '';

    // Custom Hex Color Injection
    if ($activeColor === 'custom' && !empty($config['custom_hex_color'])) {
        $hex = htmlspecialchars($config['custom_hex_color']);
        $output .= '<style>
        :root {
            --brand-primary: ' . $hex . ';
            --brand-primary-hover: ' . $hex . 'ee;
            --brand-primary-faded: ' . $hex . '1a;
            --brand-primary-gradient-v: linear-gradient(180deg, ' . $hex . ' 0%, ' . $hex . ' 100%);
        }
        </style>' . "\n";
    } elseif ($activeColor !== 'default') {
        $colorRelPath = "templates/{$activeTemplate}/core/styles/{$activeStyle}/assets/css/vars/defaults/colors/{$activeColor}.css";
        if (file_exists(ROOTDIR . '/' . $colorRelPath)) {
            $webRoot = rtrim($vars['WEB_ROOT'] ?? '', '/');
            $v = $config['theme_version'] ?? '2.3.2';
            $output .= '<link rel="stylesheet" href="' . $webRoot . '/' . $colorRelPath . '?v=' . $v . '">' . "\n";
        }
    }

    // Custom CSS from Addon Manager
    if (!empty($config['custom_css'])) {
        $output .= '<style>' . $config['custom_css'] . '</style>' . "\n";
    }

    return $output;
});

/*
 * -------------------------------------------------------------------------
 *  6. Cart / Order Checkout Optimization Hook
 * -------------------------------------------------------------------------
 */
add_hook('ClientAreaPage', -100000000, function($vars) {
    if (isset($vars['inShoppingCart']) && isset($_GET['a']) && $_GET['a'] === 'view') {
        header("Location: cart.php?a=checkout");
        exit;
    }
});
