<?php
/**
 * =========================================================================
 *  Theme: Nilom Client Theme
 *  Author: NRWThemes (https://nrwone.in)
 *  Compatibility: WHMCS 9.0.6, 9.0.6-release.1, 9.0.9+
 *  PHP Version: PHP 8.1, PHP 8.2, PHP 8.3, PHP 8.4+
 *  License: Open Source / Standalone - No License System Required
 * =========================================================================
 */

return [
    /**
     * Theme Identity & Branding
     */
    'theme_name'        => 'Nilom',
    'theme_version'     => '2.3.2',
    'author'            => 'NRWThemes',
    'author_url'        => 'https://nrwone.in',

    /**
     * Theme Style
     * Options: 'default', 'modern', 'depth', 'futuristic'
     */
    'style'             => 'default',

    /**
     * Primary Color Palette
     * Options: 'default' (blue), 'green', 'orange', 'purple', 'red'
     */
    'color'             => 'default',

    /**
     * Navigation Layout
     * Options:
     *  - 'default'        : Standard top navigation with horizontal main menu
     *  - 'condensed'      : Compact single-row navbar with centered search
     *  - 'left-nav'       : Sleek modern vertical sidebar navigation
     *  - 'left-nav-wide'  : Expanded vertical sidebar navigation with text labels
     */
    'layout'            => 'default',

    /**
     * Footer Layout
     * Options: 'default', 'extended'
     */
    'footer_layout'     => 'default',

    /**
     * Display Mode / Dark Mode
     * Options:
     *  - 'switcher'    : User toggle switch displayed in navbar (with saved cookie)
     *  - 'force_dark'  : Always dark mode for all users
     *  - 'force_light' : Always light mode (switcher disabled)
     *  - 'auto'        : Automatically adapts to user's OS / system preferences
     */
    'display_mode'      => 'switcher',

    /**
     * Navigation Options
     */
    'sticky_nav'        => true,         // Affixed/sticky header navigation on scroll
    'mobile_menu'       => 'dropdown',   // 'dropdown' or 'slide'

    /**
     * Portal Features
     */
    'hide_inactive_services' => false,  // Hide cancelled/terminated services by default
    'tld_cycle_switcher'     => true,   // Allow switching between 1-yr, 2-yr cycles on domain search
    'custom_logo_url'        => '',     // Leave empty for WHMCS index.php, or set custom URL
];
