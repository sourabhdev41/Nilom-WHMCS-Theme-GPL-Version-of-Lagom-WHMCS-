<?php
/**
 * Nilom Core Initializer
 * Theme: Nilom by NRWThemes (nrwone.in)
 * Compatibility: WHMCS 9.0.6, 9.0.9+ | PHP 8.1, 8.2, 8.3, 8.4+
 * License: Open Source / Standalone - No License Required
 */

defined('WHMCS') or die('Restricted access');
